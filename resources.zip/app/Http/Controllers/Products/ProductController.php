<?php

namespace App\Http\Controllers\Products;

use App\Http\Controllers\Controller;
use App\Models\Category\Category;
use App\Models\Product\Product;
use App\Models\ProductImage\ProductImage;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

class ProductController extends Controller
{

    // its admin product controller 
    public function store(Request $request)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($request->all(), [
                'category_id'      => 'required|exists:categories,id',
                'subcategory_id'   => 'nullable|exists:sub_categories,id',
                'name'             => 'required|string|max:255',
                'description'      => 'nullable|string',
                'clay_type'        => 'nullable|string',
                'firing_method'    => 'nullable|string',
                'glaze_type'       => 'nullable|string',
                'dimensions'       => 'nullable|string',
                'weight'           => 'nullable|string',
                'price'            => 'nullable|numeric',
                'discount_percent' => 'nullable|numeric',
                'stock_quantity'   => 'required|integer',
                'is_fragile'       => 'nullable',
                'is_handmade'      => 'nullable',
                'color'        => 'nullable|string|max:255',
                'youtube_link' => 'nullable|string|max:255',
                'images'           => 'required|array|max:5',
                'images.*'         => 'image|mimes:jpeg,png,jpg,gif|max:9999',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'status' => 500,
                    'message' => 'validation failed',
                    'err' => $validator->errors(),
                ]);
            }

            $product = Product::create([
                'category_id'      => $request->category_id,
                'subcategory_id'   => $request->subcategory_id,
                'name'             => $request->name,
                'description'      => $request->description,
                'clay_type'        => $request->clay_type,
                'firing_method'    => $request->firing_method,
                'glaze_type'       => $request->glaze_type,
                'dimensions'       => $request->dimensions,
                'weight'           => $request->weight,
                'price'            => $request->price,
                'discount_percent' => $request->discount_percent,
                'stock_quantity'   => $request->stock_quantity,
                'is_fragile'       => $request->boolean('is_fragile'),
                'is_handmade'      => $request->boolean('is_handmade'),
                'color'        => $request->color,
                'youtube_link' => $request->youtube_link,
            ]);

            $this->storeImages($request, $product->id);

            DB::commit();

            return response()->json([
                'status' => 200,
                'message' => 'product created successfully',
                'data' => $product,
            ]);
        } catch (Exception $e) {
            DB::rollBack();

            return response()->json([
                'status' => 500,
                'message' => 'something went wrong in server',
                'err' => $e->getMessage(),
            ]);
        }
    }

    public function storeImages(Request $request, $productId)
    {
        $validator = Validator::make($request->all(), [
            'images'   => 'required|array|max:5',
            'images.*' => 'image|mimes:jpeg,png,jpg,gif|max:9999',
        ]);

        if ($validator->fails()) {
            throw new Exception(json_encode($validator->errors()));
        }

        $folderPath = public_path('images');
        if (!File::exists($folderPath)) {
            File::makeDirectory($folderPath, 0755, true);
        }

        foreach ($request->file('images') as $image) {
            $filename = time() . '_' . uniqid() . '.' . $image->getClientOriginalExtension();
            $image->move($folderPath, $filename);

            ProductImage::create([
                'product_id' => $productId,
                'image'      => $filename,
            ]);
        }
    }

    public function viewProducts(Request $request)
    {
        try {
            $page = (int) $request->query('page', 1);
            $perPage = (int) $request->query('perPage', 5);
            $skip = ($page - 1) * $perPage;

            $query = Product::with('images');

            if ($request->has('sub_category_id')) {
                $query->where('subcategory_id', $request->sub_category_id);
            } elseif ($request->has('category_id')) {
                $query->where('category_id', $request->category_id);
            } else {
                return response()->json([
                    'status' => 400,
                    'message' => 'No category_id or sub_category_id provided',
                    'data' => []
                ]);
            }

            $totalProducts = $query->count();

            $products = $query->skip($skip)
                ->take($perPage)
                ->get();

            return response()->json([
                'status' => 200,
                'message' => 'Products fetched successfully',
                'data' => [
                    'products' => $products,
                    'totalPages' => ceil($totalProducts / $perPage)
                ]
            ]);
        } catch (Exception $e) {
            return response()->json([
                'status' => 500,
                'message' => 'Something went wrong in server',
                'err' => $e->getMessage()
            ]);
        }
    }

    public function fetchSingleProduct($id)
    {
        try {
            $product = Product::with('images')
                ->where('id', $id)
                ->first();

            if (!$product) {
                return response()->json([
                    'status' => 404,
                    'message' => 'Product not found',
                ]);
            }

            return response()->json([
                'status' => 200,
                'message' => 'Product fetched successfully',
                'data' => $product
            ]);
        } catch (Exception $e) {
            return response()->json([
                'status' => 500,
                'message' => 'Something went wrong in server',
                'err' => $e->getMessage()
            ]);
        }
    }

    public function fetchByStaticCategory(Request $request)
    {
        try {
         
            $validator = Validator::make($request->all(), [
                'category_title' => 'required|string',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'status' => 400,
                    'message' => 'Validation failed',
                    'err' => $validator->errors(),
                ]);
            }

            // return $abc = Product::with('images')->where('id', 1)->get();
            // We are deliberately fetching based on a static string for 4 cards.
            $normalized = strtolower(str_replace([' ', '-'], '', $request->category_title));

            $category = Category::whereRaw(
                    'LOWER(REPLACE(REPLACE(name, " ", ""), "-", "")) = ?', [$normalized]
                )
                ->orWhere('slug', strtolower($request->category_title))
                ->first();

            $products = [];
            if ($category) {
                $products = Product::with('images')
                    ->where('category_id', $category->id)
                    ->get();
            }

            return response()->json([
                'status' => 200,
                'message' => 'Products fetched successfully',
                'data' => $products
            ]);
        } catch (Exception $e) {
            return response()->json([
                'status' => 500,
                'message' => 'Something went wrong in server',
                'err' => $e->getMessage()
            ]);
        }
    }

    public function fetchMultipleProducts(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'ids' => 'required|array',
                'ids.*' => 'exists:products,id',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'status' => 400,
                    'message' => 'Validation failed',
                    'err' => $validator->errors(),
                ]);
            }

            $products = Product::with('images')
                ->whereIn('id', $request->ids)
                ->get();

            return response()->json([
                'status' => 200,
                'message' => 'Products fetched successfully',
                'data' => $products
            ]);
        } catch (Exception $e) {
            return response()->json([
                'status' => 500,
                'message' => 'Something went wrong in server',
                'err' => $e->getMessage()
            ]);
        }
    }

    public function updateBestSeller(Request $request, $id)
    {
        try {
            $validator = Validator::make($request->all(), [
                'best_seller' => 'required|boolean',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'status' => 500,
                    'message' => 'validation failed',
                    'err' => $validator->errors(),
                ]);
            }

            $product = Product::findOrFail($id);
            $product->best_seller = $request->best_seller;
            $product->save();

            return response()->json([
                'status' => 200,
                'message' => 'best seller status updated',
                'data' => $product,
            ]);
        } catch (Exception $e) {
            return response()->json([
                'status' => 500,
                'message' => 'something went wrong in server',
                'err' => $e->getMessage(),
            ]);
        }
    }

    public function productImageChange(Request $request, $imageId)
    {
        $request->validate([
            'image' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048'
        ]);

        $imageRecord = ProductImage::findOrFail($imageId);

        if ($request->hasFile('image')) {
            $oldPath = public_path('images/' . $imageRecord->image);
            if (File::exists($oldPath)) {
                File::delete($oldPath);
            }

            $file = $request->file('image');
            $filename = time().'_'.$file->getClientOriginalName();
            $file->move(public_path('images'), $filename);

            // update DB
            $imageRecord->image = $filename;
            $imageRecord->save();
        }

        return response()->json([
            'status' => 200,
            'message' => 'Product image updated successfully',
            'data' => [
                'id' => $imageRecord->id,
                'product_id' => $imageRecord->product_id,
                'image' => $imageRecord->image
            ]
        ]);
    }

    public function searchProducts(Request $request){
        $query = $request->input('q'); // matches frontend

        if (!$query) {
            return response()->json([
                'status'  => 200,
                'message' => 'No query provided',
                'data'    => []
            ]);
        }

        $searchData = Product::where('name', 'LIKE', '%'.$query.'%')
        ->limit(50)
        ->get();

        return response()->json([
            'status'  => 200,
            'message' => 'Products fetched successfully',
            'data'    => $searchData
        ]);
    }

    public function searchProductsById($id){
        $product = Product::with('images')->where('id', $id)->first();

        if (!$product) {
            return response()->json([
                'status'  => 404,
                'message' => 'Product not found',
                'data'    => null
            ]);
        }

        return response()->json([
            'status'  => 200,
            'message' => 'Product fetched successfully',
            'data'    => $product
        ]);
    }

    public function updateProduct(Request $request, $id)
    {
        try {
            $product = Product::findOrFail($id);

            // 🔹 Only updateable fields (category_id excluded)
            $updatable = [
                'disable','color','youtube_link','subcategory_id','name',
                'description','clay_type','firing_method','glaze_type',
                'dimensions','weight','price','discount_percent',
                'stock_quantity','is_fragile','is_handmade','best_seller'
            ];

            foreach ($updatable as $field) {
                if ($request->has($field)) {
                    $product->$field = $request->$field;
                }
            }

            $product->save();

            return response()->json([
                'status'  => 200,
                'message' => 'Product updated successfully',
                'data'    => $product
            ]);
        } catch (Exception $e) {
            return response()->json([
                'status'  => 500,
                'message' => 'something went wrong in server',
                'err'     => $e->getMessage()
            ]);
        }
    }


    // Public functions 
    public function fetchBestSellers()
    {
        try {
            $bestSellers = Product::with('images')
                ->where('best_seller', true)
                ->get();

            return response()->json([
                'status' => 200,
                'message' => 'Best sellers fetched successfully',
                'data' => $bestSellers
            ]);
        } catch (Exception $e) {
            return response()->json([
                'status' => 500,
                'message' => 'Something went wrong in server',
                'err' => $e->getMessage()
            ]);
        }
    } 


}
